"""Circular curved-throat kinematics; standard library, no field simulation.

Exact domain decisions use rational inputs. Trigonometric profiles, derivatives,
and quadrature checks use floating point and declared tolerances.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path
from reporting import rational


def require_observable(chart, observable):
    allowed={'material':{'tangency','constant_throughflow','zero_relative_side_flux'},
             'eulerian':{'sectional_flux_peak','side_flux_cocycle','control_volume_conservation'}}
    if chart not in allowed or observable not in allowed[chart]:
        raise ValueError('observable is not defined for that chart contract')
    return True


class Throat:
    def __init__(self, config):
        keys = {'A', 'R0', 'Rc', 'U0', 'epsilon', 's0_turns', 'profile_intervals'}
        if not isinstance(config, dict) or set(config) != keys:
            raise ValueError('throat configuration requires exactly: ' + ', '.join(sorted(keys)))
        self.exact = {key: rational(config[key], key) for key in keys - {'profile_intervals'}}
        v = self.exact
        if any(v[k] <= 0 for k in ('A', 'R0', 'Rc', 'U0')) or not 0 <= v['epsilon'] < 1:
            raise ValueError('positive lengths/speed and 0 <= epsilon < 1 are required')
        if v['Rc'] >= v['A'] or v['R0']**2 >= v['A']**2 * (1-v['epsilon']):
            raise ValueError('both tubes must stay strictly inside the coordinate radius A')
        if not 0 <= v['s0_turns'] < 1:
            raise ValueError('s0_turns must be in [0,1)')
        count = config['profile_intervals']
        if type(count) is not int or not 32 <= count <= 4096:
            raise ValueError('profile_intervals must be an integer from 32 through 4096')
        for key, value in v.items():
            numeric = float(value)
            if not math.isfinite(numeric) or (key in ('A', 'R0', 'Rc', 'U0') and not 1e-6 <= numeric <= 1e6):
                raise ValueError('reference numerics require finite inputs and positive scales within [1e-6,1e6]')
            setattr(self, key, numeric)
        if self.epsilon > .999 or min(self.R0,self.Rc)/self.A < .001 or max(self.Rc/self.A,self.R0/self.A/math.sqrt(1-self.epsilon)) > .95:
            raise ValueError('numerical reference requires epsilon <= .999, radius ratios >= .001, and maximum tube radius <= .95 A')
        self.ell = 2 * math.pi * self.A
        self.s0 = self.s0_turns * self.ell
        self.count = count

    def profile(self, s):
        phase = (s-self.s0)/self.A
        return self.U0 * (1+self.epsilon*math.cos(phase)), -self.U0*self.epsilon*math.sin(phase)/self.A

    def h(self, r, theta):
        return 1-r*math.cos(theta)/self.A

    def radius(self, s):
        U, _ = self.profile(s)
        return self.R0 * math.sqrt(self.U0/U)

    def physical_velocity(self, s, r, theta, corrected=True):
        U, derivative = self.profile(s)
        h = self.h(r, theta)
        return U, -r*derivative/(2*h if corrected else 2), 0.0

    def cartesian_point(self, s, r, theta):
        u = s/self.A
        radius = self.A-r*math.cos(theta)
        return radius*math.cos(u), radius*math.sin(u), r*math.sin(theta)

    def cartesian_velocity(self, xyz, corrected=True):
        x, y, z = xyz
        u = math.atan2(y,x)
        rho = math.hypot(x,y)
        a = self.A-rho
        r = math.hypot(a,z)
        if rho <= 0 or r == 0 or r >= self.A:
            raise ValueError('Cartesian diagnostic requires 0 < r < A and rho > 0')
        theta = math.atan2(z,a)
        vs, vr, _ = self.physical_velocity(self.A*u,r,theta,corrected)
        c, sn = math.cos(u), math.sin(u)
        ct, st = math.cos(theta), math.sin(theta)
        return -vs*sn-vr*ct*c, vs*c-vr*ct*sn, vr*st

    def divergence_fd(self, s, r, theta, step, corrected=True):
        center = self.cartesian_point(s,r,theta)
        total = 0.0
        for axis in range(3):
            plus, minus = list(center), list(center)
            plus[axis] += step
            minus[axis] -= step
            total += (self.cartesian_velocity(plus,corrected)[axis]-self.cartesian_velocity(minus,corrected)[axis])/(2*step)
        return total

    def fixed_flux(self, s):
        return math.pi*self.Rc**2*self.profile(s)[0]

    def side_flux_density(self, s, angular_points=32):
        # Integrate the velocity against the actual curved side-area element.
        values = []
        for k in range(angular_points):
            theta = 2*math.pi*(k+.5)/angular_points
            vr = self.physical_velocity(s,self.Rc,theta)[1]
            values.append(self.Rc*self.h(self.Rc,theta)*vr)
        return 2*math.pi*sum(values)/angular_points

    def side_flux_integral(self, a, b, intervals=256):
        if intervals <= 0 or intervals % 2:
            raise ValueError('Simpson integration needs a positive even interval count')
        step = (b-a)/intervals
        total = self.side_flux_density(a)+self.side_flux_density(b)
        total += sum((4 if i%2 else 2)*self.side_flux_density(a+i*step) for i in range(1,intervals))
        return total*step/3

    def rows(self):
        rows=[]
        for k in range(self.count+1):
            offset_turns=k/self.count-.5
            s=self.s0+offset_turns*self.ell
            U, derivative=self.profile(s)
            radius=self.radius(s)
            rows.append({'offset_turns':offset_turns,'s':s,'U':U,'U_prime':derivative,
                         'material_radius':radius,'material_flux':math.pi*radius**2*U,
                         'fixed_radius_flux':self.fixed_flux(s),'fixed_side_flux_per_s':self.side_flux_density(s),
                         'minimum_h_at_material_radius':1-radius/self.A})
        return rows

    def verify(self):
        speed_scale=self.U0/self.A
        divergence_tolerance=1e-6*speed_scale
        flux_scale=math.pi*self.Rc**2*self.U0
        flux_tolerance=1e-8*flux_scale
        tangency_tolerance=1e-7*self.U0
        step=self.A*1e-5
        divergences=[]
        straight_residuals=[]
        tangencies=[]
        for turns in (-.31,-.17,.08,.29):
            s=self.s0+turns*self.ell
            for theta in (.3,1.1,2.7):
                r=.6*min(self.Rc,self.radius(s))
                divergences.append(abs(self.divergence_fd(s,r,theta,step)))
                straight_residuals.append(abs(self.divergence_fd(s,r,theta,step,False)))
                radius=self.radius(s)
                radius_derivative=(self.radius(s+step)-self.radius(s-step))/(2*step)
                U,vr,_=self.physical_velocity(s,radius,theta)
                tangencies.append(abs(vr-U*radius_derivative/self.h(radius,theta)))
        segments=[(-.31,-.04),(-.12,.12),(.06,.31),(-.5,.5)]
        flux_checks=[]
        for left,right in segments:
            a,b=self.s0+left*self.ell,self.s0+right*self.ell
            numerical=self.side_flux_integral(a,b)
            expected=self.fixed_flux(a)-self.fixed_flux(b)
            flux_checks.append({'offset_turns':[left,right],'integrated_side_flux':numerical,
                                'cap_flux_difference':expected,'absolute_residual':abs(numerical-expected)})
        a,b,c=[self.s0+x*self.ell for x in (-.3,.02,.33)]
        cocycle_residual=abs((self.fixed_flux(b)-self.fixed_flux(a))+(self.fixed_flux(c)-self.fixed_flux(b))-(self.fixed_flux(c)-self.fixed_flux(a)))
        row_data=self.rows()
        material_flux_error=max(abs(row['material_flux']-math.pi*self.R0**2*self.U0) for row in row_data)
        flags={'cartesian_divergence':max(divergences)<divergence_tolerance,
               'material_tangency_finite_difference':max(tangencies)<tangency_tolerance,
               'material_throughflow_constancy':material_flux_error<1e-12*math.pi*self.R0**2*self.U0,
               'fixed_control_volume_conservation':max(x['absolute_residual'] for x in flux_checks)<flux_tolerance,
               'spatial_cocycle_additivity':cocycle_residual<flux_tolerance}
        return {'status':'PASS' if all(flags.values()) else 'FAIL',
                'evidence_kind':'KINEMATIC_NUMERICAL_FIXTURE','physical_field_verdict':'NOT_RUN',
                'exact_domain':'Rc < A and R0^2 < A^2(1-epsilon), with positive scales and 0 <= epsilon < 1',
                'checks':flags,'cartesian_points_checked':len(divergences),
                'finite_difference_step':step,'maximum_cartesian_divergence_residual':max(divergences),
                'divergence_tolerance':divergence_tolerance,
                'maximum_uncorrected_straight_field_divergence':max(straight_residuals),
                'maximum_material_tangency_residual':max(tangencies),'tangency_tolerance':tangency_tolerance,
                'material_flux_maximum_residual':material_flux_error,
                'flux_tolerance':flux_tolerance,'flux_integrals':flux_checks,
                'spatial_cocycle_residual':cocycle_residual,
                'minimum_sampled_h':min(row['minimum_h_at_material_radius'] for row in row_data)}


def write_run(config, output):
    throat=Throat(config)
    report=throat.verify()
    output=Path(output)
    output.mkdir(parents=True,exist_ok=False)
    for name, value in [('config.json',config),('throat_report.json',report)]:
        (output/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
    rows=throat.rows()
    with (output/'throat_profile.csv').open('w',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',required=True,type=Path)
    parser.add_argument('--out',required=True,type=Path,help='new output folder; existing folders are refused')
    args=parser.parse_args()
    try:
        report=write_run(json.loads(args.config.read_text(encoding='utf-8-sig')),args.out)
    except (ValueError,TypeError,OverflowError,OSError) as exc:
        parser.exit(2,f'Cannot run throat fixture: {exc}\n')
    print(json.dumps({'status':report['status'],'evidence_kind':report['evidence_kind'],'output':str(args.out)}))
    return 0 if report['status']=='PASS' else 1


if __name__=='__main__':
    raise SystemExit(main())
