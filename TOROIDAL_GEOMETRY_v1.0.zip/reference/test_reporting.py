import unittest
from reporting import scale_gate, compose_verdict


class ReportingTests(unittest.TestCase):
    def test_scale_rule_exact_boundary_and_unresolved_cases(self):
        inputs=dict(fit_validity='VALID',diagnostics='CONCORDANT',model_preference='FINITE',L_max=192,xi_upper=48)
        self.assertEqual(scale_gate(**inputs),'CLEARED')
        self.assertEqual(scale_gate(**(inputs|{'xi_upper':'48001/1000'})),'NOT_CLEARED')
        cases=[({'fit_validity':'INVALID'},'INVALID'),({'fit_validity':'NOT_RUN'},'UNRESOLVED'),
               ({'diagnostics':'DISCORDANT'},'UNRESOLVED'),({'diagnostics':'UNAVAILABLE'},'UNRESOLVED'),
               ({'model_preference':'LONG_RANGE','xi_upper':None},'INAPPLICABLE'),
               ({'model_preference':'UNDISTINGUISHED'},'UNRESOLVED'),({'xi_upper':None},'UNRESOLVED')]
        for change,expected in cases:self.assertEqual(scale_gate(**(inputs|change)),expected)
        for value in (float('inf'),0,True,'NaN'):
            with self.assertRaises(ValueError):scale_gate(**(inputs|{'xi_upper':value}))

    def test_conditional_verdict_truth_table_and_precedence(self):
        inputs=dict(q1='PASS',antecedents={'Q2':'PASS','Q3':'PASS','vison_gap':'PASS'},required_validation={'sampling':'PASS'})
        self.assertEqual(compose_verdict(**inputs),'REALIZATION_SUPPORTED')
        self.assertEqual(compose_verdict(**(inputs|{'q1':'FAIL'})),'CONDITIONAL_PREDICTION_FALSIFIED_FOR_THIS_REALIZATION')
        self.assertEqual(compose_verdict(**(inputs|{'antecedents':{'Q2':'FAIL','Q3':'PASS'}})),'REALIZATION_REJECTED')
        for status in ('NOT_RUN','UNRESOLVED','INCONCLUSIVE'):
            self.assertEqual(compose_verdict(**(inputs|{'antecedents':{'Q2':status}})),'JOINT_CLAIM_UNRESOLVED')
        self.assertEqual(compose_verdict(**(inputs|{'required_validation':{'sampling':'FAIL'}})),'NO_ADMISSIBLE_VERDICT')
        self.assertEqual(compose_verdict(**(inputs|{'required_validation':{'sampling':'NOT_RUN'}})),'JOINT_CLAIM_UNRESOLVED')
        self.assertEqual(compose_verdict(**(inputs|{'q1':'INVALID'})),'NO_ADMISSIBLE_VERDICT')
        with self.assertRaises(ValueError):compose_verdict(**(inputs|{'antecedents':{}}))
        with self.assertRaises(ValueError):compose_verdict(**(inputs|{'q1':'CLEARED'}))


if __name__=='__main__':unittest.main()
