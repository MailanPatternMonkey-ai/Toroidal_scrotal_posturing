"""Declared decision rules. These functions do not fit data or establish gates."""
from fractions import Fraction


def rational(value, name):
    if type(value) is not int and not isinstance(value, (str, Fraction)):
        raise ValueError(f'{name} must be an integer or an exact rational string')
    try:
        return Fraction(value)
    except (ValueError, ZeroDivisionError) as exc:
        raise ValueError(f'{name} is not a finite rational') from exc


def scale_gate(*, fit_validity, diagnostics, model_preference, L_max, xi_upper=None):
    """Four-length rule is an adopted finite-size convention, not a theorem."""
    if fit_validity not in ('VALID', 'INVALID', 'NOT_RUN'):
        raise ValueError('unknown fit validity')
    if diagnostics not in ('CONCORDANT', 'DISCORDANT', 'UNAVAILABLE'):
        raise ValueError('unknown diagnostic availability/concordance')
    if model_preference not in ('FINITE', 'LONG_RANGE', 'UNDISTINGUISHED'):
        raise ValueError('unknown model preference')
    size = rational(L_max, 'L_max')
    if size <= 0:
        raise ValueError('L_max must be positive')
    upper = None if xi_upper is None else rational(xi_upper, 'xi_upper')
    if upper is not None and upper <= 0:
        raise ValueError('xi_upper must be positive')
    if fit_validity == 'INVALID':
        return 'INVALID'
    if fit_validity == 'NOT_RUN' or diagnostics != 'CONCORDANT':
        return 'UNRESOLVED'
    if model_preference == 'LONG_RANGE':
        return 'INAPPLICABLE'
    if model_preference == 'UNDISTINGUISHED' or upper is None:
        return 'UNRESOLVED'
    return 'CLEARED' if size >= 4 * upper else 'NOT_CLEARED'


STATUSES = {'PASS', 'FAIL', 'INCONCLUSIVE', 'UNRESOLVED', 'INVALID', 'NOT_RUN'}


def compose_verdict(*, q1, antecedents, required_validation):
    """Compose a *conditional* claim after retaining every raw result separately.

    The caller must declare all antecedents and validation requirements. This
    checks that declaration, not whether it is scientifically complete.
    """
    if not isinstance(antecedents, dict) or not antecedents or not isinstance(required_validation, dict) or not required_validation:
        raise ValueError('nonempty named antecedents and validation requirements are required')
    results = [q1, *antecedents.values(), *required_validation.values()]
    if any(s not in STATUSES for s in results):
        raise ValueError('unknown scientific status')
    if 'INVALID' in results or 'FAIL' in required_validation.values():
        return 'NO_ADMISSIBLE_VERDICT'
    if any(s != 'PASS' for s in required_validation.values()):
        return 'JOINT_CLAIM_UNRESOLVED'
    if 'FAIL' in antecedents.values():
        return 'REALIZATION_REJECTED'
    if any(s != 'PASS' for s in antecedents.values()) or q1 not in ('PASS', 'FAIL'):
        return 'JOINT_CLAIM_UNRESOLVED'
    return 'REALIZATION_SUPPORTED' if q1 == 'PASS' else 'CONDITIONAL_PREDICTION_FALSIFIED_FOR_THIS_REALIZATION'
