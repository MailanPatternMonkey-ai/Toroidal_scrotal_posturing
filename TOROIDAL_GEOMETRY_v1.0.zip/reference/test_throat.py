import copy
import math
import unittest
from throat import Throat, require_observable

DEFAULT={'A':'10','R0':'1','Rc':'3/2','U0':'1','epsilon':'1/4','s0_turns':'0','profile_intervals':256}


class ThroatTests(unittest.TestCase):
    def test_chart_substitution_is_rejected(self):
        self.assertTrue(require_observable('material','constant_throughflow'))
        self.assertTrue(require_observable('eulerian','sectional_flux_peak'))
        with self.assertRaises(ValueError):require_observable('material','sectional_flux_peak')
        with self.assertRaises(ValueError):require_observable('eulerian','zero_relative_side_flux')

    def test_curved_cartesian_conservation_and_straight_counterexample(self):
        report=Throat(DEFAULT).verify()
        self.assertEqual(report['status'],'PASS',report)
        self.assertGreater(report['maximum_uncorrected_straight_field_divergence'],100*report['divergence_tolerance'])

    def test_metric_from_cartesian_coordinate_derivatives(self):
        t=Throat(DEFAULT)
        s,r,theta=t.ell*.17,.8,.6
        values=[s,r,theta]
        columns=[]
        for axis in range(3):
            step=1e-5
            plus,minus=list(values),list(values)
            plus[axis]+=step; minus[axis]-=step
            columns.append([(a-b)/(2*step) for a,b in zip(t.cartesian_point(*plus),t.cartesian_point(*minus))])
        expected=[t.h(r,theta)**2,1,r**2]
        for a in range(3):
            for b in range(3):
                dot=sum(x*y for x,y in zip(columns[a],columns[b]))
                self.assertAlmostEqual(dot,expected[a] if a==b else 0,places=8)

    def test_material_and_fixed_charts_have_different_predictions(self):
        t=Throat(DEFAULT)
        center,opposite=0,t.ell/2
        self.assertLess(t.radius(center),t.radius(opposite))
        self.assertGreater(t.fixed_flux(center),t.fixed_flux(opposite))
        self.assertAlmostEqual(math.pi*t.radius(center)**2*t.profile(center)[0],math.pi*t.radius(opposite)**2*t.profile(opposite)[0])
        self.assertLess(t.side_flux_integral(-.2*t.ell,-.1*t.ell),0)
        self.assertGreater(t.side_flux_integral(.1*t.ell,.2*t.ell),0)
        self.assertAlmostEqual(t.side_flux_integral(-.1*t.ell,.1*t.ell),0,places=10)

    def test_flat_and_translated_controls(self):
        flat=Throat(DEFAULT|{'epsilon':'0'})
        self.assertEqual(flat.verify()['status'],'PASS')
        self.assertTrue(all(row['fixed_side_flux_per_s']==0 for row in flat.rows()))
        self.assertEqual(len({row['material_radius'] for row in flat.rows()}),1)
        base=Throat(DEFAULT)
        shifted=Throat(DEFAULT|{'s0_turns':'1/8'})
        self.assertEqual(shifted.verify()['status'],'PASS')
        for s in (0,.1*base.ell,.45*base.ell):
            self.assertAlmostEqual(base.fixed_flux(s),shifted.fixed_flux(s+shifted.s0),places=12)
            self.assertAlmostEqual(base.radius(s),shifted.radius(s+shifted.s0),places=12)

    def test_exact_domain_and_numerical_conditioning_guards(self):
        for change in ({'Rc':'10'},{'R0':'9'},{'epsilon':'1'},{'epsilon':'-1/4'},
                       {'A':True},{'epsilon':.25},{'R0':'1/10000'},
                       {'s0_turns':'1'},{'profile_intervals':8}):
            with self.assertRaises(ValueError):Throat(DEFAULT|change)

    def test_numerical_check_for_other_admissible_shapes(self):
        for change in ({'A':'5','Rc':'2','R0':'3/2','epsilon':'1/3'},
                       {'A':'20','Rc':'1','R0':'1/2','epsilon':'1/2','s0_turns':'2/7'}):
            report=Throat(DEFAULT|change).verify()
            self.assertEqual(report['status'],'PASS',report)


if __name__=='__main__':unittest.main()
