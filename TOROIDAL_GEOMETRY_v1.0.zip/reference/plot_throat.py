"""Optional figure generation: requires matplotlib; not part of core verification."""
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
rows=list(csv.DictReader((ROOT/'examples'/'throat'/'throat_profile.csv').open(encoding='utf-8')))
x=[float(row['offset_turns']) for row in rows]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'svg.hashsalt':'toroidal-geometry-v1'})
fig,axes=plt.subplots(3,1,figsize=(10,9),sharex=True)
fig.patch.set_facecolor('#f4f6f8')
curves=[('material_radius','Material boundary radius','#006d77'),
        ('fixed_radius_flux','Through-flow in the fixed-radius tube','#3254a8'),
        ('fixed_side_flux_per_s','Outward side flux per unit arclength','#a84922')]
for ax,(field,title,color) in zip(axes,curves):
    ax.plot(x,[float(row[field]) for row in rows],color=color,lw=2.6)
    ax.set_title(title,loc='left',fontweight='bold',fontsize=12)
    ax.axvline(0,color='#687782',ls=':',lw=1)
    ax.grid(alpha=.18)
    ax.spines[['top','right']].set_visible(False)
    ax.set_xlim(-.5,.5)
axes[0].set_ylabel('Radius')
axes[1].set_ylabel('Volume / time')
axes[2].set_ylabel('Flux / length')
axes[2].axhline(0,color='#687782',lw=.8)
axes[2].text(-.27,0,'Inward',ha='center',va='bottom',color='#7c391f')
axes[2].text(.27,0,'Outward',ha='center',va='top',color='#7c391f')
axes[2].set_xlabel('Position relative to the throat, in turns: (s - s0) / circumference')
fig.suptitle('One curved throat, two different boundaries',x=.10,y=.985,ha='left',fontsize=21,fontweight='bold',color='#19364a')
fig.text(.10,.942,'Material through-flow stays constant. The fixed-radius tube exchanges fluid through its sides.',fontsize=10.5,color='#3c4e59')
fig.text(.10,.018,'KINEMATIC REFERENCE  |  A = 10, R0 = 1, Rc = 1.5, U0 = 1, amplitude = 0.25  |  No empirical field data',fontsize=9,color='#3c4e59')
fig.tight_layout(rect=(.04,.05,.98,.93),h_pad=2)
output=ROOT/'figures'
output.mkdir(exist_ok=True)
fig.savefig(output/'curved_throat.png',dpi=150,facecolor=fig.get_facecolor(),metadata={'Software':'Toroidal Geometry v1.0'})
fig.savefig(output/'curved_throat.svg',facecolor=fig.get_facecolor(),metadata={'Date':None,'Creator':'Toroidal Geometry v1.0'})
print('Saved curved_throat.png and curved_throat.svg')
