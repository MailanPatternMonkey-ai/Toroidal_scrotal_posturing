"""Exact cubical chains on rectangular three-tori. Python standard library.

This is a deterministic geometry validator, not a Monte Carlo field sampler.
Cells use ascending positive axes; orientation reversal changes the coefficient.
Boundary of an edge is head minus tail; physical divergence is minus boundary.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
from math import gcd, prod
import hashlib
import json


@dataclass(frozen=True, order=True)
class Cell:
    base: tuple[int, int, int]
    axes: tuple[int, ...]


def add(*chains):
    result = {}
    for chain in chains:
        for cell, value in chain.items():
            result[cell] = result.get(cell, 0) + value
    return {cell: value for cell, value in result.items() if value}


def scale(chain, factor):
    return {cell: value * factor for cell, value in chain.items() if value * factor}


def mod(chain, modulus):
    return {cell: value % modulus for cell, value in chain.items() if value % modulus}


class Torus:
    def __init__(self, shape=(2, 3, 4), reference_origin=(0, 0, 0)):
        if not isinstance(shape, (list, tuple)) or len(shape) != 3 or any(type(v) is not int or v < 2 or v > 16 for v in shape) or prod(shape) > 512:
            raise ValueError('shape: three integer side lengths from 2 through 16, product at most 512')
        self.shape = tuple(shape)
        if not isinstance(reference_origin, (list, tuple)) or len(reference_origin) != 3 or any(type(v) is not int or not 0 <= v < L for v, L in zip(reference_origin, shape)):
            raise ValueError('reference_origin must be a canonical lattice vertex')
        self.origin = tuple(reference_origin)

    def shift(self, base, axis, amount=1):
        point = list(base)
        point[axis] = (point[axis] + amount) % self.shape[axis]
        return tuple(point)

    def cells(self, degree):
        for base in product(*(range(L) for L in self.shape)):
            for axes in combinations(range(3), degree):
                yield Cell(base, axes)

    def check_chain(self, chain, degree):
        if not isinstance(chain, dict):
            raise ValueError('chain must be a cell-coefficient dictionary')
        for cell, value in chain.items():
            if not isinstance(cell, Cell) or len(cell.base) != 3 or len(cell.axes) != degree or any(type(a) is not int or a not in (0, 1, 2) for a in cell.axes) or cell.axes != tuple(sorted(set(cell.axes))):
                raise ValueError('invalid oriented cell')
            if any(type(v) is not int or not 0 <= v < L for v, L in zip(cell.base, self.shape)):
                raise ValueError('cell base must use canonical coordinates')
            if type(value) is not int or abs(value) > 10**12:
                raise ValueError('chain coefficient must be an integer of magnitude at most 10^12')

    def boundary(self, chain):
        result = {}
        for cell, value in chain.items():
            for i, axis in enumerate(cell.axes):
                axes = cell.axes[:i] + cell.axes[i+1:]
                for base, sign in ((self.shift(cell.base, axis), 1), (cell.base, -1)):
                    face = Cell(base, axes)
                    result[face] = result.get(face, 0) + (-1)**i * sign * value
        return {cell: value for cell, value in result.items() if value}

    def divergence(self, current):
        self.check_chain(current, 1)
        return scale(self.boundary(current), -1)

    def cycle(self, axis, orientation=1):
        if type(axis) is not int or axis not in (0, 1, 2) or type(orientation) is not int or orientation not in (-1, 1):
            raise ValueError('cycle needs an axis and signed unit orientation')
        return {Cell(self.shift(self.origin, axis, k), (axis,)): orientation for k in range(self.shape[axis])}

    def sheet(self, normal_axis, cut=0):
        if type(normal_axis) is not int or normal_axis not in (0, 1, 2) or type(cut) is not int or not 0 <= cut < self.shape[normal_axis]:
            raise ValueError('invalid sheet axis or cut')
        axes = tuple(a for a in range(3) if a != normal_axis)
        return {cell: 1 for cell in self.cells(2) if cell.axes == axes and cell.base[normal_axis] == cut}

    def cut_fluxes(self, current):
        self.check_chain(current, 1)
        result = [[0] * L for L in self.shape]
        for cell, value in current.items():
            axis = cell.axes[0]
            result[axis][cell.base[axis]] += value
        return result

    def integer_winding(self, current):
        if self.divergence(current):
            raise ValueError('integer winding requires zero integer divergence')
        cuts = self.cut_fluxes(current)
        if any(len(set(axis)) != 1 for axis in cuts):
            raise ArithmeticError('conserved current has inconsistent cuts')
        return tuple(axis[0] for axis in cuts)

    def averaged_current(self, current):
        return tuple(F(sum(axis), L) for axis, L in zip(self.cut_fluxes(current), self.shape))

    def modular_flux(self, current, modulus):
        if type(modulus) is not int or not 2 <= modulus <= 1000:
            raise ValueError('modulus must be an integer from 2 through 1000')
        if mod(self.divergence(current), modulus):
            raise ValueError('current is not closed modulo the requested modulus')
        cuts = self.cut_fluxes(current)
        residues = [[value % modulus for value in axis] for axis in cuts]
        if any(len(set(axis)) != 1 for axis in residues):
            raise ArithmeticError('modular cut independence failed')
        return tuple(axis[0] for axis in residues)

    def homology_mod2(self):
        ranks = [0]
        counts = [len(list(self.cells(k))) for k in range(4)]
        for degree in (1, 2, 3):
            target = {cell: i for i, cell in enumerate(self.cells(degree - 1))}
            columns = []
            for cell in self.cells(degree):
                bits = 0
                for face, value in self.boundary({cell: 1}).items():
                    if value % 2:
                        bits ^= 1 << target[face]
                columns.append(bits)
            ranks.append(gf2_rank(columns))
        betti = [counts[k] - ranks[k] - (ranks[k+1] if k < 3 else 0) for k in range(4)]
        return {'cell_counts': counts, 'boundary_ranks_mod2': ranks, 'betti_mod2': betti}


def gf2_rank(columns):
    pivots = {}
    for value in columns:
        while value:
            pivot = value.bit_length() - 1
            if pivot in pivots:
                value ^= pivots[pivot]
            else:
                pivots[pivot] = value
                break
    return len(pivots)


def chain_rows(chain):
    return [{'base': list(cell.base), 'axes': list(cell.axes), 'coefficient': value}
            for cell, value in sorted(chain.items()) if value]


def read_chain(rows, torus, degree):
    if not isinstance(rows, list):
        raise ValueError('chain serialization must be a list')
    chain = {}
    for row in rows:
        if not isinstance(row, dict) or set(row) != {'base', 'axes', 'coefficient'}:
            raise ValueError('each cell needs base, axes and coefficient')
        if not isinstance(row['base'], list) or not isinstance(row['axes'], list):
            raise ValueError('cell base and axes must be lists')
        if any(type(v) is not int for v in row['base'] + row['axes']):
            raise ValueError('cell coordinates and axes must be integers')
        cell = Cell(tuple(row['base']), tuple(row['axes']))
        if cell in chain:
            raise ValueError('duplicate cell entries are not accepted')
        chain[cell] = row['coefficient']
    torus.check_chain(chain, degree)
    return add(chain)


@dataclass
class State:
    current: dict
    membrane: dict
    q: tuple[int, int, int]
    sources: dict

    def as_dict(self):
        return {'current': chain_rows(self.current), 'membrane': chain_rows(self.membrane),
                'q': list(self.q), 'sources': chain_rows(self.sources)}


def state_hash(state):
    return hashlib.sha256(json.dumps(state.as_dict(), sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def validate_state(torus, state, charge_modulus=6):
    if type(charge_modulus) is not int or not 2 <= charge_modulus <= 1000 or charge_modulus % 2:
        raise ValueError('this Z2 field-state contract requires an even charge modulus')
    torus.check_chain(state.current, 1)
    torus.check_chain(state.membrane, 2)
    torus.check_chain(state.sources, 0)
    if len(state.q) != 3 or any(type(v) is not int or v not in (0, 1) for v in state.q):
        raise ValueError('q must contain exactly three binary integers')
    if any(v not in (0, 1) for v in state.membrane.values()):
        raise ValueError('membrane coefficients must be canonical mod-two values')
    divergence = torus.divergence(state.current)
    charge_defect = add(divergence, scale(state.sources, charge_modulus))
    reference = add(*(scale(torus.cycle(axis), state.q[axis]) for axis in range(3)))
    membrane_defect = mod(add(state.current, torus.boundary(state.membrane), reference), 2)
    parity = None if mod(divergence, 2) else torus.modular_flux(state.current, 2)
    modular = None if mod(divergence, charge_modulus) else torus.modular_flux(state.current, charge_modulus)
    winding = None if divergence else torus.integer_winding(state.current)
    errors = []
    if charge_defect: errors.append('CHARGE_CONSTRAINT_FAILED')
    if membrane_defect: errors.append('MEMBRANE_CHAIN_CONSTRAINT_FAILED')
    if parity is None or parity != state.q: errors.append('SECTOR_CUT_PARITY_FAILED')
    return {'status': 'VALID' if not errors else 'INVALID', 'errors': errors,
            'divergence_free': not bool(divergence), 'charge_modulus': charge_modulus,
            'source_neutrality': sum(state.sources.values()) == 0,
            'integer_winding': list(winding) if winding is not None else None,
            'cut_modular_flux': list(modular) if modular is not None else None,
            'cut_parity': list(parity) if parity is not None else None,
            'cut_fluxes': torus.cut_fluxes(state.current),
            'averaged_current': [str(v) for v in torus.averaged_current(state.current)],
            'charge_defect': chain_rows(charge_defect), 'membrane_defect_mod2': chain_rows(membrane_defect),
            'state_sha256': state_hash(state)}


def state_from_payload(payload):
    if not isinstance(payload, dict) or set(payload) != {'shape', 'reference_origin', 'charge_modulus', 'state'}:
        raise ValueError('state file requires shape, reference_origin, charge_modulus and state')
    torus = Torus(payload['shape'], payload['reference_origin'])
    data = payload['state']
    if not isinstance(data, dict) or set(data) != {'current', 'membrane', 'q', 'sources'} or not isinstance(data['q'], list):
        raise ValueError('state requires current, membrane, q and sources')
    state = State(read_chain(data['current'], torus, 1), read_chain(data['membrane'], torus, 2), tuple(data['q']), read_chain(data['sources'], torus, 0))
    return torus, state, payload['charge_modulus']


def apply_operator(torus, state, kind, axis=0, orientation=1):
    """Construct an operator outcome. No random acceptance law is implied."""
    if validate_state(torus, state)['status'] != 'VALID' or state.sources:
        raise ValueError('operator fixture requires a valid source-free state')
    if type(axis) is not int or axis not in (0, 1, 2) or type(orientation) is not int or orientation not in (-1, 1):
        raise ValueError('invalid axis or orientation')
    current, membrane, q = dict(state.current), dict(state.membrane), list(state.q)
    if kind == 'rejected': pass
    elif kind == 'cube':
        membrane = mod(add(membrane, torus.boundary({Cell(torus.origin, (0, 1, 2)): 1})), 2)
    elif kind == 'plaquette':
        face = {Cell(torus.origin, tuple(a for a in range(3) if a != axis)): 1}
        membrane = mod(add(membrane, face), 2)
        current = add(current, scale(torus.boundary(face), orientation))
    elif kind == 'closed_sheet':
        membrane = mod(add(membrane, torus.sheet(axis, torus.origin[axis])), 2)
    elif kind == 'even_cycle':
        current = add(current, scale(torus.cycle(axis), 2 * orientation))
    elif kind == 'sector':
        current = add(current, torus.cycle(axis, orientation))
        q[axis] ^= 1
    else:
        raise ValueError('unknown operator kind')
    after = State(current, membrane, tuple(q), {})
    if validate_state(torus, after)['status'] != 'VALID':
        raise ArithmeticError('constructed operator violated the state constraints')
    return after


def operator_trace(torus):
    specifications = [('rejected',0,1),('cube',0,1),('plaquette',2,-1),('closed_sheet',1,1),
                      ('even_cycle',0,1),('sector',0,1),('sector',1,-1),('sector',2,1),
                      ('sector',0,-1),('sector',0,1),('even_cycle',2,-1)]
    state = State({}, {}, (0,0,0), {})
    states = [state.as_dict()]
    ledger = []
    for index, (kind, axis, orientation) in enumerate(specifications):
        after = apply_operator(torus, state, kind, axis, orientation)
        before_W, after_W = torus.integer_winding(state.current), torus.integer_winding(after.current)
        delta = [b-a for a,b in zip(before_W, after_W)]
        eta = [(b-a)%2 for a,b in zip(state.q, after.q)]
        if eta != [d%2 for d in delta]: raise ArithmeticError('sector cocycle failed')
        ledger.append({'event_id':index,'evidence_kind':'CONSTRUCTED_OPERATOR_FIXTURE',
                       'sampling_address':'elementary_operator','operator':kind,'axis':axis,'orientation':orientation,
                       'accepted':kind!='rejected','state_before':state_hash(state),'state_after':state_hash(after),
                       'q_before':list(state.q),'q_after':list(after.q),'W_before':list(before_W),'W_after':list(after_W),
                       'delta_W':delta,'eta':eta,'state_validation':'VALID'})
        state = after
        states.append(state.as_dict())
    return states, ledger


def character_fixture():
    labels = list(product((0,1), repeat=3))
    weights = {q: prod(((4,1),(2,1),(3,1))[a][q[a]] for a in range(3)) for q in labels}
    sign = lambda h,q: (-1)**sum(a*b for a,b in zip(h,q))
    direct = {h: sum(F(sign(h,q)*weights[q],8) for q in labels) for h in labels}
    inverse = {q: sum(sign(h,q)*direct[h] for h in labels) for q in labels}
    if inverse != weights or any(v<0 for v in direct.values()): raise ArithmeticError('character identity failed')
    p = {q:F(weights[q],sum(weights.values())) for q in labels}
    r = {h:direct[h]/direct[(0,0,0)] for h in labels}
    return {'scope':'SYNTHETIC_POSITIVE_CHARACTER_COEFFICIENTS; not direct/dual model enumeration',
            'labels':[list(q) for q in labels],'dual_coefficients':[str(weights[q]) for q in labels],
            'direct_coefficients':[str(direct[q]) for q in labels],'sector_probabilities':[str(p[q]) for q in labels],
            'direct_ratios':[str(r[h]) for h in labels],
            'full_sum_equals_zero_dual':sum(direct.values())==weights[(0,0,0)],
            'inverse_exact':True,'all_ratio_bounds':all(0<=x<=1 for x in r.values()),
            'zero_sector_dominates':all(p[(0,0,0)]>=v for v in p.values())}


def reachable(vertices, edges, start):
    vertices = set(vertices)
    if start not in vertices or any(a not in vertices or b not in vertices for a,b in edges):
        raise ValueError('graph vertices are not declared')
    seen, stack = {start}, [start]
    while stack:
        x = stack.pop()
        for a,b in edges:
            if a == x and b not in seen: seen.add(b); stack.append(b)
    return seen


def diamond_report(m, n):
    if type(m) is not int or type(n) is not int or not 2<=m<=32 or not 2<=n<=32:
        raise ValueError('diamond periods must be integers from 2 through 32')
    seen, stack = {(0,0)}, [(0,0)]
    while stack:
        x,y = stack.pop()
        for dx,dy in ((1,1),(1,-1),(-1,1),(-1,-1)):
            point=((x+dx)%m,(y+dy)%n)
            if point not in seen: seen.add(point);stack.append(point)
    return {'shape':[m,n],'reachable_vertices':len(seen),'index':m*n//len(seen),
            'predicted_index':gcd(2,m,n),'representative_parity_well_defined':m%2==0 and n%2==0}


def projection_closure(matrix, labels):
    if len(matrix)!=len(labels) or not labels or any(len(row)!=len(labels) for row in matrix):
        raise ValueError('invalid finite kernel dimensions')
    if any(any(type(p) is not int and not isinstance(p, F) for p in row) for row in matrix):
        raise ValueError('kernel entries must be exact integers or Fractions')
    if any(any(p<0 for p in row) or sum(row)!=1 for row in matrix):
        raise ValueError('finite kernel must be nonnegative and stochastic')
    targets=sorted(set(labels))
    for x in range(len(labels)):
        for y in range(x+1,len(labels)):
            if labels[x]!=labels[y]: continue
            for target in targets:
                px=sum(matrix[x][z] for z in range(len(labels)) if labels[z]==target)
                py=sum(matrix[y][z] for z in range(len(labels)) if labels[z]==target)
                if px!=py:return {'status':'FAILED','scope':'complete supplied finite kernel','witness_states':[x,y],
                                  'common_label':labels[x],'target_label':target,'probabilities':[str(px),str(py)]}
    return {'status':'CLOSED','scope':'complete supplied finite kernel'}
