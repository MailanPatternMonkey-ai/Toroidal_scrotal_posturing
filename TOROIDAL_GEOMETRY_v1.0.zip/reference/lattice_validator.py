"""Validate finite toroidal chains or run deterministic reference fixtures.

No random proposals, acceptance weights, thermalization, or field estimates.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
from lattice import (Cell, State, Torus, add, scale, mod, validate_state,
                     state_from_payload, operator_trace, character_fixture,
                     diamond_report, reachable, projection_closure)


def sourced_example(shape, modulus=6):
    torus=Torus(shape)
    current={Cell((0,0,0),(0,)):modulus}
    sources={cell:-value//modulus for cell,value in torus.divergence(current).items()}
    state=State(current,{},(0,0,0),sources)
    return {'shape':list(shape),'reference_origin':[0,0,0],'charge_modulus':modulus,'state':state.as_dict()}


def fixtures(config):
    if not isinstance(config,dict) or set(config)!={'shape','reference_origin'}:
        raise ValueError('fixture config requires exactly shape and reference_origin')
    torus=Torus(config['shape'],config['reference_origin'])
    topology=torus.homology_mod2()
    boundary_count=0
    for degree in (1,2,3):
        for cell in torus.cells(degree):
            if torus.boundary(torus.boundary({cell:1})):
                raise ArithmeticError('integer boundary-square failed')
            boundary_count+=1
    states,events=operator_trace(torus)
    modular=[]
    edge={Cell(torus.origin,(0,)):1}
    for modulus in (2,3,4,6,8):
        current=add(torus.cycle(0),scale(torus.cycle(1),-2),scale(edge,modulus))
        residue=torus.modular_flux(current,modulus)
        modular.append({'modulus':modulus,'cut_flux':list(residue),'expected':[1,(-2)%modulus,0],
                        'status':'PASS' if residue==(1,(-2)%modulus,0) else 'FAIL',
                        'general_parity_reduction':modulus%2==0})
    witnesses=[]
    for length in (4,6):
        payload=sourced_example((length,2,2))
        space,state,modulus=state_from_payload(payload)
        witnesses.append({'shape':payload['shape'],'description':'one positive charge-six edge',
                          'validation':validate_state(space,state,modulus)})
    labels={'A':(0,0),'B':(1,0),'C':(0,0),'D':(0,1)}
    edges=[('A','B'),('B','A'),('C','D'),('D','C')]
    component=reachable(labels,edges,'A')
    P=[[F(1,10),F(1,10),F(4,5)],[F(2,5),F(2,5),F(1,5)],[F(1,4),F(1,4),F(1,2)]]
    pi=[F(1,4),F(1,4),F(1,2)]
    stationary=[sum(pi[x]*P[x][y] for x in range(3)) for y in range(3)]==pi
    report={'evidence_kind':'EXACT_DETERMINISTIC_GEOMETRY','config':config,'physical_field_verdict':'NOT_RUN',
            'topology':topology,'integer_boundary_square_cells_checked':boundary_count,
            'constructed_operator_count':len(events),'final_state':validate_state(torus,state_from_payload({
                'shape':list(torus.shape),'reference_origin':list(torus.origin),'charge_modulus':6,'state':states[-1]})[1]),
            'modular_current_fixtures':modular,'source_counterexamples':witnesses,
            'character_transform':character_fixture(),
            'accessibility_counterexample':{'increment_span_size':4,'reachable_states':sorted(component),
                'reachable_sector_labels':[list(x) for x in sorted({labels[x] for x in component})],
                'conclusion':'global increment span does not establish accessible state paths'},
            'projection_counterexample':{'matrix':[[str(p) for p in row] for row in P],
                'labels':['A','A','B'],'stationary_distribution':[str(p) for p in pi],
                'stationarity_verified':stationary,'strong_closure':projection_closure(P,['A','A','B']),
                'stationary_projected_process':'iid fair A/B; identical incoming A columns reset hidden A distribution'},
            'work_stopping_counterexample':{'unit_iid_bit_law':['1/2','1/2'],
                'costs':[1,2],'stop_rule':'first cumulative work >= 2',
                'endpoint_bit_law':['1/4','3/4'],'scope':'finite probability calculation, not an actual worm trace'},
            'diamond_rectangles':[diamond_report(m,n) for m,n in ((4,6),(4,5),(3,5),(6,3))]}
    checks={'homology':topology['betti_mod2']==[1,3,3,1],
            'final_state':report['final_state']['status']=='VALID',
            'modular_currents':all(row['status']=='PASS' for row in modular),
            'source_witnesses':all(row['validation']['status']=='VALID' and row['validation']['integer_winding'] is None for row in witnesses),
            'character_identity':report['character_transform']['inverse_exact'],
            'stationarity':stationary,
            'strong_closure_witness':report['projection_counterexample']['strong_closure']['status']=='FAILED',
            'diamond_indices':all(row['index']==row['predicted_index'] for row in report['diamond_rectangles'])}
    report['checks']=checks
    report['status']='PASS' if all(checks.values()) else 'FAIL'
    payload={'shape':list(torus.shape),'reference_origin':list(torus.origin),'charge_modulus':6,'state':states[-1]}
    return report,states,events,payload


def write_json(path,value):
    Path(path).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')


def run_fixture(config,output):
    report,states,events,payload=fixtures(config)
    output=Path(output)
    output.mkdir(parents=True,exist_ok=False)
    for name,value in [('config.json',config),('lattice_report.json',report),('operator_states.json',states),('state_input.json',payload),
                       ('source_counterexample_L4.json',sourced_example((4,2,2))),('source_counterexample_L6.json',sourced_example((6,2,2)))]:
        write_json(output/name,value)
    (output/'operator_events.jsonl').write_text(''.join(json.dumps(row,sort_keys=True)+'\n' for row in events),encoding='utf-8',newline='\n')
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--config',type=Path,help='run exact constructed fixtures')
    mode.add_argument('--state',type=Path,help='validate a supplied integer-current/membrane state')
    parser.add_argument('--out',type=Path,required=True,help='new output folder; existing folders are refused')
    args=parser.parse_args()
    try:
        payload=json.loads((args.config or args.state).read_text(encoding='utf-8-sig'))
        if args.config:
            report=run_fixture(payload,args.out)
        else:
            torus,state,modulus=state_from_payload(payload)
            report=validate_state(torus,state,modulus)
            args.out.mkdir(parents=True,exist_ok=False)
            write_json(args.out/'state_report.json',report)
    except (ValueError,TypeError,OSError) as exc:
        parser.exit(2,f'Cannot validate lattice input: {exc}\n')
    print(json.dumps({'status':report['status'],'output':str(args.out)}))
    return 0 if report['status'] in ('PASS','VALID') else 2


if __name__=='__main__':
    raise SystemExit(main())
