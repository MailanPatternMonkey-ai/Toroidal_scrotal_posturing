"""Independent conservation, topology, obstruction, and input-safety checks."""
import copy
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from lattice import (Cell, Torus, State, add, scale, mod, validate_state, state_from_payload,
                     apply_operator, operator_trace, character_fixture, diamond_report, projection_closure, reachable)
from lattice_validator import fixtures, sourced_example


class LatticeTests(unittest.TestCase):
    def test_boundary_square_every_cell_three_shapes(self):
        for shape in ((2,2,2),(2,3,4),(3,4,5)):
            t=Torus(shape)
            for degree in (1,2,3):
                for cell in t.cells(degree):
                    self.assertEqual(t.boundary(t.boundary({cell:1})),{})

    def test_known_torus_betti_numbers(self):
        for shape in ((2,2,2),(2,3,4),(3,4,5)):
            data=Torus(shape).homology_mod2()
            self.assertEqual(data['betti_mod2'],[1,3,3,1])
            self.assertEqual(sum((-1)**k*n for k,n in enumerate(data['cell_counts'])),0)

    def test_all_cuts_pair_reference_cycles(self):
        for shape,origin in [((2,3,4),(0,0,0)),((3,4,5),(2,3,4))]:
            t=Torus(shape,origin)
            for axis in range(3):
                expected=tuple(1 if j==axis else 0 for j in range(3))
                self.assertEqual(t.integer_winding(t.cycle(axis)),expected)
                self.assertEqual(t.averaged_current(t.cycle(axis)),expected)
                self.assertEqual(t.boundary(t.sheet(axis)),{})

    def test_edge_accounting_and_layer_identity_independently(self):
        t=Torus((3,4,5))
        current={cell:(i*17)%11-5 for i,cell in enumerate(t.cells(1))}
        physical={}
        for cell,value in current.items():
            tail=cell.base
            head=list(tail)
            head[cell.axes[0]]=(head[cell.axes[0]]+1)%t.shape[cell.axes[0]]
            for point,sign in ((tail,1),(tuple(head),-1)):
                physical[point]=physical.get(point,0)+sign*value
        self.assertEqual(t.divergence(current),{Cell(p,()):v for p,v in physical.items() if v})
        flux=t.cut_fluxes(current)
        for axis,L in enumerate(t.shape):
            for k in range(L):
                layer=sum(value for point,value in physical.items() if point[axis]==k)
                self.assertEqual(flux[axis][k]-flux[axis][(k-1)%L],layer)

    def test_sources_break_integer_winding_and_average_parity(self):
        for length,average in ((4,F(3,2)),(6,F(1))):
            t,state,m=state_from_payload(sourced_example((length,2,2)))
            result=validate_state(t,state,m)
            self.assertEqual(result['status'],'VALID')
            self.assertEqual(result['cut_parity'],[0,0,0])
            self.assertIsNone(result['integer_winding'])
            self.assertEqual(t.averaged_current(state.current)[0],average)
            with self.assertRaises(ValueError):t.integer_winding(state.current)

    def test_modular_currents_and_odd_modulus_obstruction(self):
        t=Torus((3,4,5))
        for m in (2,3,4,6,8):
            current=add(t.cycle(0),scale(t.cycle(1),-2),{Cell((0,0,0),(2,)):m})
            self.assertEqual(t.modular_flux(current,m),(1,(-2)%m,0))
        self.assertNotEqual(0%2,3%2)
        with self.assertRaises(ValueError):validate_state(t,State({}, {}, (0,0,0), {}),3)
        with self.assertRaises(ValueError):t.modular_flux({Cell((0,0,0),(0,)):1},6)

    def test_same_sector_does_not_imply_even_link_difference(self):
        t=Torus()
        face={Cell((0,0,0),(0,1)):1}
        current=t.boundary(face)
        self.assertEqual(t.integer_winding(current),(0,0,0))
        self.assertTrue(any(v%2 for v in current.values()))
        self.assertEqual(validate_state(t,State(current,face,(0,0,0),{}))['status'],'VALID')
        self.assertIn('MEMBRANE_CHAIN_CONSTRAINT_FAILED',validate_state(t,State(current,{},(0,0,0),{}))['errors'])

    def test_invalid_sector_charge_and_open_current(self):
        t=Torus()
        states=[State(t.cycle(0),{},(0,0,0),{}),State({}, {}, (0,0,0),{Cell((0,0,0),()):1}),
                State({Cell((0,0,0),(0,)):1},{},(0,0,0),{})]
        self.assertTrue(all(validate_state(t,s)['status']=='INVALID' for s in states))

    def test_operators_and_signed_cocycle_telescope(self):
        t=Torus((3,4,5),(2,3,4))
        states,events=operator_trace(t)
        self.assertEqual(len(events),11)
        self.assertEqual(events[0]['state_before'],events[0]['state_after'])
        total=[sum(row['delta_W'][a] for row in events) for a in range(3)]
        self.assertEqual(total,[3,-1,-1])
        self.assertEqual([sum(row['eta'][a] for row in events)%2 for a in range(3)],[1,1,1])
        for row in events:self.assertEqual(row['eta'],[v%2 for v in row['delta_W']])
        for raw in states:
            space,state,m=state_from_payload({'shape':list(t.shape),'reference_origin':list(t.origin),'charge_modulus':6,'state':raw})
            self.assertEqual(validate_state(space,state,m)['status'],'VALID')
            reversed_state=State(scale(state.current,-1),state.membrane,state.q,scale(state.sources,-1))
            self.assertEqual(validate_state(space,reversed_state,m)['status'],'VALID')

    def test_axis_orientation_operator_sweep(self):
        t=Torus()
        for axis,sign,kind in product(range(3),(-1,1),('plaquette','sector','even_cycle','closed_sheet')):
            state=apply_operator(t,State({}, {}, (0,0,0), {}),kind,axis,sign)
            expected=tuple((sign if kind=='sector' else 2*sign if kind=='even_cycle' else 0) if j==axis else 0 for j in range(3))
            self.assertEqual(t.integer_winding(state.current),expected)

    def test_character_transform_independent_separable_formula(self):
        data=character_fixture()
        for label,coefficient in zip(data['labels'],data['direct_coefficients']):
            expected=F((4+(-1)**label[0])*(2+(-1)**label[1])*(3+(-1)**label[2]),8)
            self.assertEqual(F(coefficient),expected)
        self.assertEqual(sum(F(x) for x in data['sector_probabilities']),1)
        self.assertTrue(data['full_sum_equals_zero_dual'])

    def test_accessibility_span_counterexample_and_connected_action(self):
        edges=[('A','B'),('B','A'),('C','D'),('D','C')]
        self.assertEqual(reachable('ABCD',edges,'A'),{'A','B'})
        sectors=list(product((0,1),repeat=3))
        edges=[]
        for q in sectors:
            for a in range(3):
                other=list(q);other[a]^=1
                edges.append((q,tuple(other)))
        self.assertEqual(reachable(sectors,edges,(0,0,0)),set(sectors))

    def test_diamond_all_small_rectangles(self):
        for m,n in product(range(2,10),repeat=2):
            data=diamond_report(m,n)
            self.assertEqual(data['index'],data['predicted_index'])
            self.assertEqual(data['index']==2,m%2==0 and n%2==0)

    def test_lumpability_and_stationary_weak_closure_distinction(self):
        P=[[F(1,10),F(1,10),F(4,5)],[F(2,5),F(2,5),F(1,5)],[F(1,4),F(1,4),F(1,2)]]
        self.assertEqual(projection_closure(P,['A','A','B'])['status'],'FAILED')
        pi=[F(1,4),F(1,4),F(1,2)]
        for word in product(('A','B'),repeat=5):
            vector=[pi[i] if ('A','A','B')[i]==word[0] else F(0) for i in range(3)]
            for label in word[1:]:
                vector=[sum(vector[i]*P[i][j] for i in range(3)) if ('A','A','B')[j]==label else F(0) for j in range(3)]
            self.assertEqual(sum(vector),F(1,32))
        self.assertEqual(projection_closure([[F(1,2)]*2]*2,['A','A'])['status'],'CLOSED')
        with self.assertRaises(ValueError):projection_closure([[.5,.5],[.5,.5]],['A','A'])

    def test_work_stopping_endpoint_law_by_tree(self):
        endpoint={0:F(0),1:F(0)}
        for first in (0,1):
            if first==1:endpoint[1]+=F(1,2)
            else:
                for second in (0,1):endpoint[second]+=F(1,4)
        self.assertEqual(endpoint,{0:F(1,4),1:F(3,4)})

    def test_strict_input_rejection(self):
        for shape in (None,[True,2,2],[1,2,2],[17,2,2],[16,16,16]):
            with self.assertRaises(ValueError):Torus(shape)
        base=sourced_example((4,2,2))
        for field,value in [('coefficient',6.0),('axes',[True]),('base',[[0],0,0])]:
            payload=copy.deepcopy(base)
            payload['state']['current'][0][field]=value
            with self.assertRaises(ValueError):state_from_payload(payload)
        duplicate=copy.deepcopy(base)
        duplicate['state']['current']*=2
        with self.assertRaises(ValueError):state_from_payload(duplicate)

    def test_fixture_and_cli_refuse_overwrite(self):
        report,_,_,payload=fixtures({'shape':[2,3,4],'reference_origin':[0,0,0]})
        self.assertEqual(report['status'],'PASS')
        cli=Path(__file__).with_name('lattice_validator.py')
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            source=root/'state.json'; source.write_text(json.dumps(payload),encoding='utf-8')
            command=[sys.executable,'-B',str(cli),'--state',str(source),'--out',str(root/'result')]
            first=subprocess.run(command,capture_output=True,text=True)
            self.assertEqual(first.returncode,0,first.stderr)
            frozen=(root/'result'/'state_report.json').read_bytes()
            self.assertEqual(subprocess.run(command,capture_output=True).returncode,2)
            self.assertEqual((root/'result'/'state_report.json').read_bytes(),frozen)
            payload['state']['q']=[0,0,0]
            source.write_text(json.dumps(payload),encoding='utf-8')
            command[-1]=str(root/'invalid')
            self.assertEqual(subprocess.run(command,capture_output=True).returncode,2)
            self.assertEqual(json.loads((root/'invalid'/'state_report.json').read_text())['status'],'INVALID')


if __name__=='__main__':unittest.main()
