"""Independent PR #2 provenance/runner checks; never writes into the checkout.

Fault injection below is only for the runner's failure reporting. It is not
part of, or counted toward, the unmodified 20+7 protocol test result.
"""
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve()
OUT = Path(__file__).resolve().parent
HEAD = "1030a509b1afba7f6940332d620eacbe637a6379"
BASE = "53eb51f4b4bb8798ac00aeb3d0eb2c641fff5c20"
SNAPSHOT = "56ee3c88c8eda58d242220c29bc1003663562947"
EXT = "extensions.c6_sender_authentication.run_review"
manifest = json.loads((ROOT / "extensions/c6_sender_authentication/baseline.json").read_text())

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)

preservation = {}
base_tree = {}
head_tree = {}
for revision, table in [(BASE, base_tree), (HEAD, head_tree)]:
    for entry in git("ls-tree", "-rz", revision).split(b"\0"):
        if entry:
            metadata, name = entry.split(b"\t", 1)
            table[name.decode()] = metadata.decode()
preservation["base_file_count"] = len(base_tree)
preservation["all_base_git_entries_unchanged_in_head"] = all(head_tree.get(k) == v for k, v in base_tree.items())
preservation["added_files"] = sorted(set(head_tree) - set(base_tree))
preservation["git_status_after_pr_runner"] = git("status", "--porcelain").decode()
preservation["pinned_originals_identical_at_snapshot_base_and_head"] = {
    name: git("show", f"{SNAPSHOT}:{name}") == git("show", f"{BASE}:{name}") == (ROOT / name).read_bytes()
    for name in manifest["source_sha256"]
}
with zipfile.ZipFile(ROOT / "Corner_Relay_Alpha_C6_Reference_v0.1.zip") as z:
    prefix = "Corner_Relay_Alpha_C6_Reference_v0.1/"
    old_receipt = json.loads(z.read(prefix + "execution_provenance.json"))
    preservation["packaged_source_hash_checks"] = {
        name: sha(z.read(prefix + name)) == expected
        for name, expected in old_receipt["artifact_file_sha256"].items()
    }
    preservation["root_historical_receipt_matches_archive"] = (ROOT / "execution_provenance.json").read_bytes() == z.read(prefix + "execution_provenance.json")
    trace = json.loads(z.read(prefix + "reference_trace.json"))
    canonical_trace = json.dumps(trace["trace"], sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    preservation["historical_trace_content_hash_verified_separately_from_file_hash"] = sha(canonical_trace) == old_receipt["reference_trace_sha256"] == trace["trace_sha256"]
preservation["historical_loose_file_sha256"] = {
    name: sha((ROOT / name).read_bytes())
    for name in ["execution_provenance.json", "Corner_Relay_Test_Log.txt"]
}

def fixture(destination):
    destination.mkdir()
    for name in [*manifest["source_sha256"], "execution_provenance.json", "Corner_Relay_Test_Log.txt"]:
        shutil.copyfile(ROOT / name, destination / name)
    shutil.copytree(ROOT / "extensions", destination / "extensions")

def run_case(name, alteration=None, command=None):
    with tempfile.TemporaryDirectory(prefix="c6-independent-") as temporary:
        root = Path(temporary) / "fixture"
        fixture(root)
        if alteration:
            alteration(root)
        evidence = OUT / ("runner-check-" + name)
        result = subprocess.run(command or [sys.executable, "-B", "-m", EXT, "--output", str(evidence)], cwd=root, text=True, capture_output=True)
        (OUT / (name + "-process.txt")).write_text(result.stdout + result.stderr)
        receipt_path = evidence / "execution_receipt.json"
        receipt = json.loads(receipt_path.read_text()) if receipt_path.exists() else None
        return {"exit_code": result.returncode, "receipt_exists": receipt is not None, "receipt_status": receipt.get("status") if receipt else None, "output_files": sorted(p.name for p in evidence.iterdir()) if evidence.exists() else []}

def alter_history(root):
    for name in ["execution_provenance.json", "Corner_Relay_Test_Log.txt"]:
        p = root / name
        p.write_bytes(p.read_bytes() + b"\n")

checks = {}
checks["modified_loose_historical_records"] = run_case("altered-history", alter_history)
checks["changed_pinned_packet"] = run_case("changed-packet", lambda root: (root / "FROZEN_PACKET.txt").write_bytes(b"SIMULATED CHANGED PACKET\n"))
fault_output = OUT / "runner-check-trace-exception"
fault_code = f'''import sys
from extensions.c6_sender_authentication import run_review
import reference_trace
def unavailable(*args, **kwargs):
    raise OSError("SIMULATED trace destination failure; runner reporting check only")
reference_trace.write_reference_trace = unavailable
sys.argv = ["run_review", "--output", {str(fault_output)!r}]
raise SystemExit(run_review.main())
'''
checks["unexpected_trace_exception"] = run_case("trace-exception", command=[sys.executable, "-B", "-c", fault_code])

old_output = OUT / "pr2-1030a509-run"
old_receipt_hash = sha((old_output / "execution_receipt.json").read_bytes())
reused = subprocess.run([sys.executable, "-B", "-m", EXT, "--output", str(old_output)], cwd=ROOT, capture_output=True, text=True)
checks["existing_output_directory"] = {"exit_code": reused.returncode, "receipt_unchanged": old_receipt_hash == sha((old_output / "execution_receipt.json").read_bytes())}
checks["git_status_after_all_checks"] = git("status", "--porcelain").decode()
summary = {"head": HEAD, "base": BASE, "prior_snapshot": SNAPSHOT, "preservation": preservation, "runner_checks": checks}
(OUT / "independent_checks.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
