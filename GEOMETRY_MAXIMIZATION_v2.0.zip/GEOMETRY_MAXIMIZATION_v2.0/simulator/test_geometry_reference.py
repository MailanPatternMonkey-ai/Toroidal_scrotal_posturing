"""Independent arithmetic oracles, model identities, error bounds and CLI tests."""
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from geometry_reference import (
    ALPHA, TAU, Q5, approximate_step, exact_records, h, inverse_h,
    label_certificate, parse_phase, run_reference, safe_phase_residual, validate_config,
)

HERE = Path(__file__).resolve().parent


def isqrt_floor_nalpha(n):
    return 0 if n == 0 else (3 * n - math.isqrt(5 * n * n) - 1) // 2


def isqrt_bin(n):
    return isqrt_floor_nalpha(39 * n) - 39 * isqrt_floor_nalpha(n)


class ExactPhaseTests(unittest.TestCase):
    def test_algebra_and_exact_order(self):
        root = Q5(0, 1)
        self.assertEqual(root * root, Q5(5))
        self.assertEqual((1 + root) / (1 + root), Q5(1))
        for numerator in range(-17, 18):
            for denominator in (1, 2, 7, 19):
                x = Q5(F(numerator, denominator))
                self.assertEqual(x.floor(), math.floor(F(numerator, denominator)))
                self.assertEqual(x.ceil(), math.ceil(F(numerator, denominator)))
        # Pell approximants are extremely close to integers. No float ordering.
        p, q = 9, 4
        for _ in range(30):
            self.assertEqual(p * p - 5 * q * q, 1)
            tiny = Q5(p, -q)
            self.assertTrue(0 < tiny < 1)
            self.assertEqual(tiny.floor(), 0)
            self.assertEqual((-tiny).floor(), -1)
            p, q = 9 * p + 20 * q, 4 * p + 9 * q
        with self.assertRaises(ZeroDivisionError):
            _ = root / 0

    def test_10000_departures_against_independent_integer_square_root(self):
        total = 0
        counts = {}
        events = []
        for record in exact_records(10000, Q5()):
            n = record["n"]
            self.assertEqual(record["bin"], isqrt_bin(n))
            self.assertEqual(record["next_bin"], isqrt_bin(n + 1))
            expected_slip = 15 - (isqrt_bin(n + 1) - isqrt_bin(n)) % 39
            self.assertEqual(record["slip"], expected_slip)
            total += record["slip"]
            if record["slip"]:
                events.append(n)
            if n + 1 in (39, 507, 10000):
                counts[n + 1] = total
        self.assertEqual(counts, {39: 5, 507: 53, 10000: 1034})
        self.assertEqual(set(b - a for a, b in zip(events, events[1:])), {9, 10})

    def test_boundary_convention(self):
        at_tau = TAU / 39
        records = list(exact_records(3, at_tau))
        self.assertEqual(records[0]["rho"], TAU)
        self.assertEqual(records[0]["slip"], 0)
        self.assertEqual(records[0]["jump"], 15)
        self.assertEqual(records[1]["rho"], Q5())
        self.assertEqual(records[1]["slip"], 1)
        tiny = F(1, 10**40)
        below = next(exact_records(1, at_tau - tiny))
        above = next(exact_records(1, at_tau + tiny))
        self.assertEqual((below["slip"], above["slip"]), (1, 0))
        for j in range(39):
            row = next(exact_records(1, Q5(F(j, 39))))
            self.assertEqual((row["bin"], row["rho"], row["slip"]), (j, Q5(), 1))

    def test_factor_recurrences_and_telescope_for_nonzero_phases(self):
        for start in (Q5(F(1, 7)), Q5(F(38, 39)), ALPHA, TAU / 39):
            rho = (39 * start).frac()
            initial_rho = rho
            z = (13 * start).frac()
            strand = (39 * start).floor() % 3
            count = 0
            for row in exact_records(257, start):
                self.assertEqual((row["rho"], row["z"], row["strand"]), (rho, z, strand))
                count += row["slip"]
                rho = (rho - TAU).frac()
                z = (z - TAU / 3).frac()
                strand = (strand - row["slip"]) % 3
            self.assertEqual(Q5(count), 257 * TAU + rho - initial_rho)
            self.assertTrue(-1 < Q5(count) - 257 * TAU < 1)

    def test_configuration_rejects_ambiguous_or_out_of_domain_input(self):
        base = {"steps": 39, "theta0": "0", "epsilon": "0.01"}
        invalid = [dict(base, steps=x) for x in (0, -1, True, 1.0, 100001)]
        invalid += [dict(base, theta0=x) for x in ("1", "-1/2", 0.1, "nan", {"a": "0"})]
        invalid += [dict(base, epsilon=x) for x in ("1", "-1", "0.999", 0.01, "inf", "1/0")]
        invalid += [dict(base, unused=True), {}, [], dict(base, theta0="9" * 101)]
        for config in invalid:
            with self.subTest(config=config), self.assertRaises(ValueError):
                validate_config(config)
        self.assertEqual(parse_phase({"a": "-29/26", "b": "1/2"}), TAU / 39)


class CoordinateTests(unittest.TestCase):
    def test_inverse_and_uniform_residual_against_analytic_bound(self):
        for e in (F(-99, 100), F(-1, 4), F(-1, 100), F(1, 100), F(1, 4), F(99, 100)):
            epsilon = float(e)
            bound = float(safe_phase_residual(e))
            for j in range(1024):
                phase = j / 1024
                x = inverse_h(phase, epsilon)
                self.assertLessEqual(abs(h(x, epsilon) - phase), 1e-14)
                # Lift the mod-one step back to the branch near x+alpha.
                gx = approximate_step(phase, epsilon)
                gx += round(phase + ALPHA.approximate() - gx)
                residual = h(gx, epsilon) - h(phase, epsilon) - ALPHA.approximate()
                self.assertLessEqual(abs(residual), bound + 2e-14)

    def test_old_physical_bins_really_change_the_observation(self):
        x1 = inverse_h(ALPHA.approximate(), 0.25)
        self.assertEqual(math.floor(39 * x1), 13)
        self.assertEqual((39 * ALPHA).floor(), 14)
        self.assertLess(abs(x1 - 0.349737755708554), 1e-14)

    def test_certificate_uses_strict_margin_and_separates_numeric_execution(self):
        e = F(1, 100)
        bound = safe_phase_residual(e)
        self.assertFalse(label_certificate(Q5(bound), 1, e))
        self.assertTrue(label_certificate(Q5(2 * bound), 1, e))
        self.assertFalse(label_certificate(Q5(), 1, e))
        self.assertTrue(label_certificate(Q5(), 0, e))
        self.assertTrue(label_certificate(Q5(), 100, F(0)))
        result = run_reference({"steps": 507, "theta0": "0", "epsilon": "0.01"})
        self.assertEqual(result["summary"]["slip_count"], 53)
        self.assertGreater(result["summary"]["ideal_bin_certified_count"], 0)
        self.assertEqual(result["summary"]["certified_rows_with_numeric_mismatch"], 0)
        self.assertIn("not a certificate of floating-point execution", result["evidence"]["certificate_scope"])

    def test_nonzero_and_negative_warp_starting_phases(self):
        for e in ("-0.01", "0.01"):
            for phase in ("1/7", "19/39", {"a": "-29/26", "b": "1/2"}):
                result = run_reference({"steps": 64, "theta0": phase, "epsilon": e})
                for row in result["rows"]:
                    if row["ideal_bin_certified"] and not row["numeric_bin_agrees"]:
                        # Initial bin boundaries expose roundoff in h(inverse_h).
                        # The ideal certificate intentionally does not certify it.
                        self.assertEqual(row["n"], 0)
                        self.assertEqual(row["boundary_margin"], {"a": "0", "b": "0"})
                self.assertLess(result["summary"]["max_inverse_residual_numeric"], 1e-14)


class InterfaceTests(unittest.TestCase):
    def test_cli_exports_deterministically_and_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            config = root / "config.json"
            config.write_text(json.dumps({"steps": 39, "theta0": "0", "epsilon": "0.01"}), encoding="utf-8")
            command = [sys.executable, "-B", str(HERE / "geometry_reference.py"), "--config", str(config)]
            for name in ("first", "second"):
                run = subprocess.run(command + ["--out", str(root / name)], capture_output=True, text=True)
                self.assertEqual(run.returncode, 0, run.stderr)
            for file in (root / "first").iterdir():
                self.assertEqual(file.read_bytes(), (root / "second" / file.name).read_bytes())
            for line in (root / "first" / "RUN_SHA256SUMS.txt").read_text().splitlines():
                digest, name = line.split("  ", 1)
                self.assertEqual(digest, hashlib.sha256((root / "first" / name).read_bytes()).hexdigest())
            result = json.loads((root / "first" / "run.json").read_text())
            self.assertEqual((len(result["rows"]), result["summary"]["slip_count"]), (39, 5))
            rerun = subprocess.run(command + ["--out", str(root / "first")], capture_output=True, text=True)
            self.assertNotEqual(rerun.returncode, 0)
            self.assertIn("choose a new output directory", rerun.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
