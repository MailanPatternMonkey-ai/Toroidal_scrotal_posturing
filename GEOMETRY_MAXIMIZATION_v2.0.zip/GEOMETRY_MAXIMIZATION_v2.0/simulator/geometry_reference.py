"""Geometry Maximization 2.0: exact phase reference, numerical coordinates.

Python 3.10+, standard library only. See ../SIMULATION_PROTOCOL_v0.5.md.
Q5 arithmetic is adapted from the preserved v1.1 verifier. No source file is
executed or imported. This module does not implement a field-theory sampler.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from decimal import Decimal, localcontext
from fractions import Fraction
import hashlib
import io
import json
import math
from pathlib import Path
import sys

VERSION = "2.0"
MAX_STEPS = 100_000


@dataclass(frozen=True)
class Q5:
    """a + b sqrt(5), with exact rational coefficients and exact ordering."""
    a: Fraction = Fraction(0)
    b: Fraction = Fraction(0)

    def __post_init__(self):
        object.__setattr__(self, "a", Fraction(self.a))
        object.__setattr__(self, "b", Fraction(self.b))

    @staticmethod
    def cast(value):
        return value if isinstance(value, Q5) else Q5(value)

    def __add__(self, other):
        other = self.cast(other)
        return Q5(self.a + other.a, self.b + other.b)

    __radd__ = __add__

    def __neg__(self):
        return Q5(-self.a, -self.b)

    def __sub__(self, other):
        return self + -self.cast(other)

    def __rsub__(self, other):
        return self.cast(other) + -self

    def __mul__(self, other):
        other = self.cast(other)
        return Q5(self.a * other.a + 5 * self.b * other.b,
                  self.a * other.b + self.b * other.a)

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = self.cast(other)
        denominator = other.a * other.a - 5 * other.b * other.b
        if not denominator:
            raise ZeroDivisionError("zero Q5 denominator")
        return self * Q5(other.a / denominator, -other.b / denominator)

    def sign(self):
        a, b = self.a, self.b
        if not b:
            return (a > 0) - (a < 0)
        if not a or (a > 0) == (b > 0):
            return (b > 0) - (b < 0)
        d = a * a - 5 * b * b
        return ((a > 0) - (a < 0)) * ((d > 0) - (d < 0))

    def __lt__(self, other):
        return (self - other).sign() < 0

    def __le__(self, other):
        return (self - other).sign() <= 0

    def __gt__(self, other):
        return (self - other).sign() > 0

    def __ge__(self, other):
        return (self - other).sign() >= 0

    def floor(self):
        # sqrt(5) lies strictly between 2 and 3. Binary search uses no floats.
        p, q = self.a + 2 * self.b, self.a + 3 * self.b
        lo, hi = math.floor(min(p, q)), math.floor(max(p, q)) + 1
        while hi - lo > 1:
            middle = (lo + hi) // 2
            if self < middle:
                hi = middle
            else:
                lo = middle
        return lo

    def ceil(self):
        return -(-self).floor()

    def frac(self):
        return self - self.floor()

    def as_dict(self):
        return {"a": str(self.a), "b": str(self.b)}

    def decimal(self, places=25):
        # Extra guard digits also handle cancellation in large coefficients.
        digits = max(len(str(abs(v))) for f in (self.a, self.b)
                     for v in (f.numerator, f.denominator))
        with localcontext() as ctx:
            ctx.prec = places + 25 + digits
            a = Decimal(self.a.numerator) / Decimal(self.a.denominator)
            b = Decimal(self.b.numerator) / Decimal(self.b.denominator)
            return format(a + b * Decimal(5).sqrt(), f".{places}f")

    def approximate(self):
        return float(self.decimal())


ALPHA = Q5(Fraction(3, 2), Fraction(-1, 2))
TAU = 15 - 39 * ALPHA


def rational(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, str)):
        raise ValueError(f"{name} must be an integer or a rational/decimal string")
    if len(str(value)) > 100:
        raise ValueError(f"{name} is limited to 100 characters")
    try:
        result = Fraction(value)
    except (ValueError, ZeroDivisionError) as exc:
        raise ValueError(f"invalid {name}: use a value such as '1/7' or '0.01'") from exc
    if max(result.numerator.bit_length(), result.denominator.bit_length()) > 256:
        raise ValueError(f"{name} coefficients exceed the 256-bit input limit")
    return result


def parse_phase(value):
    if isinstance(value, dict):
        if set(value) != {"a", "b"}:
            raise ValueError("theta0 must have exactly the keys 'a' and 'b'")
        phase = Q5(rational(value["a"], "theta0.a"), rational(value["b"], "theta0.b"))
    else:
        phase = Q5(rational(value, "theta0"))
    if phase < 0 or not phase < 1:
        raise ValueError("theta0 must lie in the half-open interval [0, 1)")
    return phase


def validate_config(config):
    if not isinstance(config, dict):
        raise ValueError("configuration must be a JSON object")
    expected = {"steps", "theta0", "epsilon"}
    if set(config) != expected:
        raise ValueError("configuration requires exactly: steps, theta0, epsilon")
    steps = config["steps"]
    if type(steps) is not int or not 1 <= steps <= MAX_STEPS:
        raise ValueError(f"steps must be an integer in [1, {MAX_STEPS}]")
    theta0 = parse_phase(config["theta0"])
    epsilon = rational(config["epsilon"], "epsilon")
    if abs(epsilon) >= 1:
        raise ValueError("epsilon must satisfy |epsilon| < 1")
    # Exact labels remain meaningful arbitrarily near the critical value, but
    # this numerical coordinate renderer is deliberately restricted.
    if abs(epsilon) > Fraction(99, 100):
        raise ValueError("the coordinate renderer supports |epsilon| <= 0.99")
    return steps, theta0, epsilon


def exact_records(steps, theta0):
    """Yield N departing observations. The terminal state is theta_N."""
    phase = theta0
    for n in range(steps):
        scaled = 39 * phase
        bin_id = scaled.floor()
        rho = scaled - bin_id
        next_phase = (phase + ALPHA).frac()
        next_bin = (39 * next_phase).floor()
        slip = int(rho < TAU)
        jump = (next_bin - bin_id) % 39
        if jump != 15 - slip:
            raise ArithmeticError("exact departing-jump identity failed")
        yield {"n": n, "theta": phase, "rho": rho,
               "z": (13 * phase).frac(), "bin": bin_id,
               "strand": bin_id % 3, "slip": slip, "jump": jump,
               "next_bin": next_bin}
        phase = next_phase


def h(x, epsilon):
    return x + epsilon * math.sin(math.tau * x) / math.tau


def inverse_h(phase, epsilon):
    """Numerical inverse in [0,1]; endpoints are retained exactly as floats."""
    if phase == 0 or phase == 1 or epsilon == 0:
        return phase
    lo, hi = 0.0, 1.0
    for _ in range(60):
        middle = (lo + hi) / 2
        if h(middle, epsilon) < phase:
            lo = middle
        else:
            hi = middle
    return (lo + hi) / 2


def approximate_step(x, epsilon):
    y = x + ALPHA_FLOAT
    d = (math.sin(math.tau * x) - math.sin(math.tau * y)) / math.tau
    return (y + epsilon * d - epsilon * epsilon * math.cos(math.tau * y) * d) % 1.0


ALPHA_FLOAT = ALPHA.approximate()


def safe_phase_residual(epsilon):
    """Exact rational upper bound on the ideal real-valued G residual.

    c <= 1/pi < 1/3 and pi*c*c <= 1/pi < 1/3 give this bound.
    This does not enclose floating-point evaluation errors.
    """
    e = abs(Fraction(epsilon))
    return e ** 3 * (1 + (1 + e) ** 2) / 3


def label_certificate(phase, n, epsilon):
    rho = (39 * phase).frac()
    margin = min(rho, 1 - rho) / 39
    bound = n * safe_phase_residual(epsilon)
    # n=0 is identical initial data; epsilon=0 makes ideal G the exact rotation,
    # including boundary points. Otherwise the separation must be strict.
    return n == 0 or epsilon == 0 or Q5(bound) < margin


def circular_distance(a, b):
    return abs((a - b + 0.5) % 1.0 - 0.5)


def run_reference(config):
    steps, theta0, epsilon = validate_config(config)
    e = float(epsilon)
    residual = safe_phase_residual(epsilon)
    records = []
    slips = []
    approx_x = inverse_h(theta0.approximate(), e)
    max_inverse_residual = 0.0
    max_phase_error = 0.0
    for exact in exact_records(steps, theta0):
        n, phase, rho = exact["n"], exact["theta"], exact["rho"]
        phase_float = phase.approximate()
        reference_x = inverse_h(phase_float, e)
        transported = h(approx_x, e) % 1.0
        numeric_bin = min(38, math.floor(39 * transported))
        margin = min(rho, 1 - rho) / 39
        certificate = label_certificate(phase, n, epsilon)
        phase_error = circular_distance(transported, phase_float)
        inverse_residual = abs(h(reference_x, e) - phase_float)
        max_inverse_residual = max(max_inverse_residual, inverse_residual)
        max_phase_error = max(max_phase_error, phase_error)
        if exact["slip"]:
            slips.append(n)
        records.append({
            "n": n, "theta": phase.as_dict(), "theta_decimal": phase.decimal(),
            "rho_decimal": rho.decimal(), "z_decimal": exact["z"].decimal(),
            "bin": exact["bin"], "strand": exact["strand"],
            "slip": exact["slip"], "jump": exact["jump"], "next_bin": exact["next_bin"],
            "reference_x_numeric": reference_x,
            "approximate_x_numeric": approx_x,
            "approximate_phase_numeric": transported,
            "approximate_bin_numeric": numeric_bin,
            "phase_error_numeric": phase_error,
            "boundary_margin": margin.as_dict(),
            "ideal_phase_error_bound": str(n * residual),
            "ideal_bin_certified": certificate,
            "numeric_bin_agrees": numeric_bin == exact["bin"],
        })
        approx_x = approximate_step(approx_x, e)
    terminal_phase = (theta0 + steps * ALPHA).frac()
    rho0 = (39 * theta0).frac()
    rhoN = (39 * terminal_phase).frac()
    count = len(slips)
    discrepancy = Q5(count) - steps * TAU
    if Q5(count) != steps * TAU + rhoN - rho0 or not -1 < discrepancy < 1:
        raise ArithmeticError("exact telescoping count check failed")
    gaps = [b - a for a, b in zip(slips, slips[1:])]
    certified = sum(row["ideal_bin_certified"] for row in records)
    numeric_mismatches = sum(not row["numeric_bin_agrees"] for row in records)
    certified_numeric_mismatches = sum(row["ideal_bin_certified"] and
                                       not row["numeric_bin_agrees"] for row in records)
    c = abs(math.sin(math.pi * ALPHA_FLOAT)) / math.pi
    sharper = abs(e) ** 3 * (c + math.pi * c * c * (1 + abs(e)) ** 2)
    canonical_config = {"steps": steps, "theta0": theta0.as_dict(), "epsilon": str(epsilon)}
    config_bytes = json.dumps(canonical_config, sort_keys=True, separators=(",", ":")).encode()
    return {
        "schema_version": "geometry-reference/2.0", "software_version": VERSION,
        "config": canonical_config, "config_sha256": hashlib.sha256(config_bytes).hexdigest(),
        "conventions": {"phase_unit": "cycles", "observation_rows": "n=0,...,N-1",
                        "slip_alignment": "departing n -> n+1", "bins": "half-open",
                        "slip_test": "rho < tau", "seed": "not applicable: deterministic"},
        "constants": {"alpha": ALPHA.as_dict(), "alpha_decimal": ALPHA.decimal(),
                      "tau": TAU.as_dict(), "tau_decimal": TAU.decimal()},
        "summary": {
            "steps": steps, "slip_count": count, "slip_rate_numeric": count / steps,
            "count_discrepancy": discrepancy.as_dict(),
            "count_discrepancy_decimal": discrepancy.decimal(),
            "telescoping_exact": True, "strict_count_error_below_one": True,
            "terminal_theta": terminal_phase.as_dict(), "terminal_rho": rhoN.as_dict(),
            "slip_indices": slips, "observed_complete_gaps": sorted(set(gaps)),
            "gap_9_count": gaps.count(9), "gap_10_count": gaps.count(10),
            "one_step_phase_bound_rational": str(residual),
            "one_step_coordinate_bound_rational": str(residual / (1 - abs(epsilon))),
            "sharper_one_step_phase_bound_numeric": sharper,
            "haar_possible_error_cover_rational": str(min(Fraction(1), 39 * residual * steps * (steps - 1))),
            "ideal_bin_certified_count": certified,
            "numeric_bin_mismatch_count": numeric_mismatches,
            "certified_rows_with_numeric_mismatch": certified_numeric_mismatches,
            "max_phase_error_numeric": max_phase_error,
            "max_inverse_residual_numeric": max_inverse_residual,
        },
        "evidence": {
            "phase_and_labels": "exact Q(sqrt(5)) arithmetic",
            "ideal_G_bound": "analytic bound; rational comparisons exact",
            "coordinates_and_actual_G_iteration": "floating point; no interval enclosure",
            "certificate_scope": "ideal real-valued G from identical initial data; not a certificate of floating-point execution",
            "field_simulation": "NOT_IMPLEMENTED",
            "physical_validation": "NOT_ESTABLISHED",
        },
        "rows": records,
    }


CSV_FIELDS = ["n", "theta_decimal", "rho_decimal", "z_decimal", "bin", "strand",
              "slip", "jump", "next_bin", "reference_x_numeric", "approximate_x_numeric",
              "approximate_phase_numeric", "approximate_bin_numeric", "phase_error_numeric",
              "ideal_phase_error_bound", "ideal_bin_certified", "numeric_bin_agrees"]


def export_run(result, folder):
    folder = Path(folder)
    names = ("run.json", "summary.json", "trace.csv", "RUN_SHA256SUMS.txt")
    folder.mkdir(parents=True, exist_ok=True)
    if any((folder / name).exists() for name in names):
        raise ValueError("output already contains run artifacts; choose a new output directory")
    (folder / "run.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    summary = {key: value for key, value in result.items() if key != "rows"}
    (folder / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=CSV_FIELDS, extrasaction="ignore", lineterminator="\n")
    writer.writeheader()
    writer.writerows(result["rows"])
    (folder / "trace.csv").write_text(stream.getvalue(), encoding="utf-8", newline="")
    sums = "".join(f"{hashlib.sha256((folder / name).read_bytes()).hexdigest()}  {name}\n"
                   for name in names[:-1])
    (folder / "RUN_SHA256SUMS.txt").write_text(sums, encoding="utf-8")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", required=True, type=Path, help="JSON configuration file")
    parser.add_argument("--out", required=True, type=Path, help="new output directory")
    args = parser.parse_args(argv)
    try:
        config = json.loads(args.config.read_text(encoding="utf-8-sig"))
        # Refuse accidental reuse before doing the computation.
        if any((args.out / name).exists() for name in ("run.json", "summary.json", "trace.csv", "RUN_SHA256SUMS.txt")):
            raise ValueError("output already contains run artifacts; choose a new output directory")
        result = run_reference(config)
        export_run(result, args.out)
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
    summary = result["summary"]
    print(f"Exact reference: {summary['steps']} departing observations, {summary['slip_count']} slips.")
    print(f"Count discrepancy: {summary['count_discrepancy_decimal']} (strictly between -1 and 1).")
    print(f"Ideal G label certificates: {summary['ideal_bin_certified_count']}/{summary['steps']}.")
    print(f"Numerical label mismatches: {summary['numeric_bin_mismatch_count']} (separate floating-point check).")
    print(f"Saved run.json, summary.json, trace.csv and checksums to {args.out.resolve()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
