# Geometry Master kit 2.4

Start with [GEOMETRY_MASTER.md](GEOMETRY_MASTER.md). It is the one-file reference to drop into another chat or workspace. It includes Geometry Maximization, Hidden Quotient, Toroidal, GQG, thermodynamic and clock distinctions, source lineage, and the latest verified additions.

[The recovery review](GEOMETRY_MAXIMIZATION_INTAKE_REVIEW_2026-10-18.md) explains what this archive added. The [fresh receipt](GEOMETRY_MAXIMIZATION_INTAKE_2026-10-18.json) records 36 passing tests, 11 reproduced examples, numerical limitations and preservation checks.

For runnable reference models, extract either preserved release into its own folder and open its README:

- [Geometry Maximization v2.0](releases/GEOMETRY_MAXIMIZATION_v2.0.zip): exact phase model, numerical comparison, protocol v0.5, five configurations and an offline explorer.
- [Toroidal Geometry v1.0](releases/TOROIDAL_GEOMETRY_v1.0.zip): exact lattice validator, curved-throat checks, protocol v0.6 and six configurations. Its baseline also contains the identical Geometry ZIP; that duplication is preserved.

Both release verifiers run with the Python standard library. Their original commands and input limits are in their READMEs. Keep release files together; the outer mixed collection is not a runnable package. The optional plot generator is separate and was not run in this intake. Browser interaction was not freshly tested.

The master is readable without any linked source. Some source links record original absolute workspace locations and will only resolve on that machine; the releases and review receipts in this kit are the portable copies for this intake. Historical source records outside this kit remain separately referenced.

These are verified mathematical reference computations. The full production field sampler and physical experiments remain outstanding. The original 12 GB source collection remains preserved separately; this compact kit contains the selected releases and review evidence.

The kit SHA256SUMS.txt covers every other file in this kit. It identifies bytes, not independent scientific validation. Historical source receipts remain distinguished from fresh execution under review/.
